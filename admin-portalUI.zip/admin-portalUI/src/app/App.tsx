import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Layout } from '@/app/components/Layout';
import { Dashboard } from '@/app/pages/Dashboard';
import { CrowdAnalysis } from '@/app/pages/CrowdAnalysis';
import { QRIssue } from '@/app/pages/QRIssue';
import { Logs } from '@/app/pages/Logs';
import { Placeholder } from '@/app/pages/Placeholder';

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/spots" element={<CrowdAnalysis />} />
          <Route path="/events" element={<Placeholder title="イベント管理" description="イベント管理機能は開発中です" />} />
          <Route path="/schedule" element={<Placeholder title="オープンキャンパス日程" description="日程管理機能は開発中です" />} />
          <Route path="/qr" element={<QRIssue />} />
          <Route path="/logs" element={<Logs />} />
          <Route path="/settings" element={<Placeholder title="設定" description="システム設定は開発中です" />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
